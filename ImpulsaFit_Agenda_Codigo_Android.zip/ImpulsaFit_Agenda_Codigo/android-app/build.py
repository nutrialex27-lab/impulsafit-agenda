#!/usr/bin/env python3
"""Build a signed Android APK with SDK Build Tools, a platform JAR and ECJ.
Signing password is read only from IF_AGENDA_SIGNING_PASSWORD.
"""
from pathlib import Path
import argparse, os, subprocess, zipfile
p=argparse.ArgumentParser()
p.add_argument('--tools',required=True);p.add_argument('--platform',required=True)
p.add_argument('--compiler',required=True);p.add_argument('--keystore',required=True)
p.add_argument('--out',required=True);p.add_argument('--alias',default='impulsafit-agenda')
a=p.parse_args()
root=Path(__file__).resolve().parent
build=root/'build';build.mkdir(exist_ok=True)
for name in ['classes','dex','generated']:(build/name).mkdir(exist_ok=True)
tools=Path(a.tools).resolve(); platform=str(Path(a.platform).resolve())
def run(*args):subprocess.run([str(x) for x in args],check=True,cwd=root)
assert os.environ.get('IF_AGENDA_SIGNING_PASSWORD'),'Missing signing password environment variable'
assert (root/'assets/index.html').exists(),'Generate Android assets first'
print('Compiling Android sources',flush=True)
run('java','-jar',a.compiler,'-source','8','-target','8','-nowarn','-proc:none','-classpath',platform,'-d',build/'classes',root/'src/com/impulsafit/agenda/MainActivity.java')
print('Compiling app resources',flush=True)
run(tools/'aapt2','compile','--dir',root/'res','-o',build/'resources.zip')
run(tools/'aapt2','link','-I',platform,'--manifest',root/'AndroidManifest.xml','--auto-add-overlay','--java',build/'generated','-A',root/'assets','-o',build/'unsigned.apk',build/'resources.zip')
classes=sorted((build/'classes').rglob('*.class'))
assert classes,'No Android classes were generated'
print('Generating Android bytecode',flush=True)
run('java','-cp',tools/'lib/d8.jar','com.android.tools.r8.D8','--release','--min-api','26','--lib',platform,'--output',build/'dex',*classes)
with zipfile.ZipFile(build/'unsigned.apk','a',zipfile.ZIP_DEFLATED) as z:
 for dex in (build/'dex').glob('*.dex'):z.write(dex,dex.name)
run(tools/'zipalign','-f','-p','4',build/'unsigned.apk',build/'aligned.apk')
out=Path(a.out).resolve();out.parent.mkdir(exist_ok=True,parents=True)
print('Signing APK',flush=True)
run('java','-jar',tools/'lib/apksigner.jar','sign','--ks',a.keystore,'--ks-key-alias',a.alias,'--ks-pass','env:IF_AGENDA_SIGNING_PASSWORD','--key-pass','env:IF_AGENDA_SIGNING_PASSWORD','--v1-signing-enabled','true','--v2-signing-enabled','true','--v3-signing-enabled','true','--out',out,build/'aligned.apk')
print('Verifying signature and manifest',flush=True)
run('java','-jar',tools/'lib/apksigner.jar','verify','--verbose','--print-certs',out)
run(tools/'aapt2','dump','badging',out)
print('APK:',out,'bytes:',out.stat().st_size,flush=True)
