# IF Agenda · Android 0.4.0 beta

Android 8 o posterior. Paquete com.impulsafit.agenda, código de versión 4. Se conserva la firma anterior: instala la actualización encima de la app, sin desinstalarla. Exporta antes una copia JSON desde Ajustes.

## Uso

- La agenda se guarda en el móvil. No necesita iniciar sesión en ChatGPT.
- Con Respuestas directas activado, cada mensaje incluye una página individual de Condes con Confirmar y Cancelar. El cliente pulsa una opción; no envía otro WhatsApp.
- La respuesta y su hora se guardan en el servidor y se recogen con Internet al abrir la app, recuperar el foco o cada 45 segundos mientras está visible. No hay recepción en segundo plano ni notificaciones push garantizadas.
- Preparar WhatsApp al guardar abre el aviso en Android, pero siempre hay que pulsar Enviar. No se usa la API de pago de WhatsApp. En reservas repetidas se prepara la primera y se comunican las demás desde sus fichas.
- Puedes desactivar Respuestas directas para utilizar las opciones anteriores por WhatsApp y registrar las respuestas manualmente.
- Se conservan el plazo de cada cita y la política de Condes: el silencio no cancela; ausencia o cancelación fuera de plazo consume sesión. Se contabilizan sesiones consumidas sin gestionar un saldo de bonos.
- Solo se comparten fecha, duración, servicio, ubicación pública y normativa. Nombres, teléfonos y notas permanecen en la agenda local.
- Las copias JSON contienen los datos y los accesos de edición de reservas: guárdalas en privado. Los enlaces y las respuestas pueden restaurarse desde la copia.
- El único permiso añadido es INTERNET. No se piden contactos, cámara, ubicación ni acceso general al almacenamiento. La vista local solo puede conectar por HTTPS al servidor de respuestas configurado.

## Construcción

Instala dependencias en la raíz con npm ci y genera la interfaz con node android-app/build-assets.mjs. Compila usando android-app/build.py con Build Tools 35, Android 35 y ECJ 3.40.0. La contraseña se recibe exclusivamente desde IF_AGENDA_SIGNING_PASSWORD. Reutiliza el almacén de firma conservado aparte; no está en el código, en el ZIP ni en GitHub.

El código del servicio público, esquema y migraciones están en response-service/. La agenda general sigue usando su almacenamiento local o su edición web privada; las dos agendas no se sincronizan entre sí.

## Verificación

Compilación, firma APK v2/v3, paquete y versión, 17 pruebas de agenda y sincronización, y 7 pruebas del servicio con SQLite real superadas. Confirmación y cancelación comprobadas desde una página cliente publicada hasta su aparición automática en la agenda del navegador. Esta actualización requiere probar la instalación y la conexión nativa en un Android físico. El alojamiento depende de los límites y disponibilidad de la cuenta; no se promete gratuidad perpetua de terceros.
