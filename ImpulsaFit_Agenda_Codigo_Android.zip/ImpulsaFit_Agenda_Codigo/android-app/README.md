# ImpulsaFit Agenda · Android

APK de prueba para Android 8 o posterior. Nombre en el móvil: **IF Agenda**. Paquete: `com.impulsafit.agenda`. Versión APK: `0.3.0-beta.1` (código 3).

## Funcionamiento

- La agenda completa se incluye en el APK: no necesita entrar en ChatGPT ni cargar una página externa.
- Los clientes y reservas se guardan en el almacenamiento privado de la aplicación en ese móvil. No se sincronizan con la edición web.
- Configura tu número de WhatsApp en Ajustes o al preparar el primer mensaje. Cada mensaje incluye dos enlaces: Confirmar sesión y Cancelar sesión. El cliente pulsa el enlace y después Enviar; la respuesta llega a tu número.
- En la ficha de la reserva registra la respuesta y su fecha de recepción. La cancelación se clasifica por esa fecha. Sin respuesta al vencer el plazo, la reserva se muestra como confirmada sin respuesta. Realizadas, cancelaciones fuera de plazo y ausencias computan como sesiones consumidas; no existe un saldo de bonos ni deducción automática.
- La normativa se atribuye a Condes Wellness & Fitness. El número de envío es el que esté abierto en WhatsApp.
- Los mensajes de WhatsApp requieren abrir WhatsApp y pulsar Enviar. La aplicación no envía mensajes automáticamente.
- Ajustes permite exportar copias JSON mediante el selector de archivos de Android y restaurarlas desde un archivo elegido por el usuario.
- La exportación ICS utiliza el mismo selector. Después se importa en la aplicación de calendario elegida.
- Cada exportación JSON conserva además una copia dentro de la app. Desde Acerca de la app se puede volver a guardar la última copia.
- La aplicación no solicita permisos de contactos, cámara, ubicación ni acceso general al almacenamiento. Las páginas externas se abren en la aplicación correspondiente.

Al desinstalar una app Android se eliminan sus datos locales. Guarda una copia JSON antes de desinstalar. Las actualizaciones con el mismo paquete y la misma firma conservan los datos.

## Construcción reproducible

La interfaz comparte los componentes de la agenda. `build-assets.mjs` adapta el guardado, los enlaces externos, la copia de texto y los selectores de archivo al contenedor Android. No cambia la edición web.

1. En la raíz del proyecto, instala las dependencias con `npm ci`.
2. Genera la interfaz Android: `node android-app/build-assets.mjs`.
3. Prepara SDK Build Tools 35.0.0, la plataforma Android 35 y ECJ 3.40.0.
4. Define la contraseña del almacén de firma en `IF_AGENDA_SIGNING_PASSWORD`.
5. Ejecuta `python3 android-app/build.py --tools RUTA_BUILD_TOOLS --platform RUTA_ANDROID_JAR --compiler RUTA_ECJ_JAR --keystore RUTA_CLAVE --out ImpulsaFit_Agenda_Android.apk`.

El almacén de firma y su contraseña se conservan por separado y nunca se incluyen en el repositorio, el ZIP de código ni los archivos de distribución. Hay que reutilizar esa firma para futuras actualizaciones.

Herramientas utilizadas:

- `https://dl.google.com/android/repository/build-tools_r35_linux.zip` · SHA-1 publicado en el repositorio oficial: `2cfaa0bbb2336e9ec18ed3ecea84fa2e2af607bc`.
- `https://dl.google.com/android/repository/platform-35_r02.zip` · SHA-1 publicado: `0bb560a90a7a2cbd0dd8348224d518b638fe7949`.
- ECJ: `https://repo.maven.apache.org/maven2/org/eclipse/jdt/ecj/3.40.0/ecj-3.40.0.jar`.

## Verificación realizada

Compilación Java contra Android 35, empaquetado de recursos, generación DEX, alineación y verificación de firma APK v2/v3. Se comprobó que el manifiesto permite iniciar la actividad, contiene el icono y no solicita permisos adicionales. La interfaz y el almacenamiento local de la agenda ya se probaron en navegador. Esta entrega no ha pasado una prueba de instalación y uso en un dispositivo Android físico o emulador.
