package com.impulsafit.agenda;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** Local agenda with HTTPS access only to its reservation response service. */
public final class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String RESPONSES_HOST = "impulsafit-respuestas.nutrialex-27.chatgpt.site";
    private static final String START = "https://" + HOST + "/assets/index.html";
    private static final int IMPORT_FILE = 41;
    private static final int EXPORT_FILE = 42;
    private WebView web;
    private ValueCallback<Uri[]> importCallback;
    private byte[] exportBytes;
    private String exportName;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(243,245,248));
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                Insets edge = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                view.setPadding(edge.left, edge.top, edge.right, edge.bottom);
            } else {
                view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(), insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        web.addJavascriptInterface(new NativeBridge(), "IFNative");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) && HOST.equals(uri.getHost()) && "/assets/index.html".equals(uri.getPath())) {
                    try {
                        WebResourceResponse response = new WebResourceResponse("text/html", "UTF-8", getAssets().open("index.html"));
                        java.util.Map<String,String> headers = new java.util.HashMap<>();
                        headers.put("Content-Security-Policy", "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; font-src data:; connect-src https://" + RESPONSES_HOST + "; object-src 'none'; base-uri 'none'; form-action 'none'");
                        response.setResponseHeaders(headers);
                        return response;
                    } catch (Exception e) { return emptyResponse(); }
                }
                if ("https".equals(uri.getScheme()) && RESPONSES_HOST.equals(uri.getHost()) && uri.getPort()==-1) return null;
                return emptyResponse();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (START.equals(request.getUrl().toString())) return false;
                openExternal(request.getUrl().toString());
                return true;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (START.equals(url)) return false;
                openExternal(url);
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (importCallback != null) importCallback.onReceiveValue(null);
                importCallback = callback;
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("application/json");
                try { startActivityForResult(pick, IMPORT_FILE); }
                catch (ActivityNotFoundException e) { importCallback.onReceiveValue(null); importCallback=null; toast("No se ha encontrado un selector de archivos."); }
                return true;
            }
        });
        root.addView(web, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        root.requestApplyInsets();
        web.loadUrl(START);
    }

    private static WebResourceResponse emptyResponse() {
        return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
    }

    private void toast(String message) {
        runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
    }

    private void openExternal(String url) {
        if (url == null || url.length() > 20000) return;
        Uri uri;
        try { uri=Uri.parse(url); } catch (Exception e) { return; }
        String scheme=uri.getScheme();
        if (!"https".equals(scheme) && !"http".equals(scheme) && !"tel".equals(scheme) && !"mailto".equals(scheme)) return;
        runOnUiThread(() -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); }
            catch (ActivityNotFoundException e) { toast("No hay una aplicación disponible para abrir este enlace."); }
        });
    }

    private void chooseExport(String name, byte[] bytes, String mime) {
        if (exportBytes != null) { toast("Termina de guardar el archivo anterior."); return; }
        exportBytes=bytes; exportName=name;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_TITLE,name);
        try { startActivityForResult(intent, EXPORT_FILE); }
        catch (ActivityNotFoundException e) { exportBytes=null; exportName=null; toast("No se pudo abrir el selector. La copia también está conservada dentro de la aplicación."); }
    }

    public final class NativeBridge {
        @JavascriptInterface public void openExternal(String url) { MainActivity.this.openExternal(url); }
        @JavascriptInterface public void copyText(String text) {
            if (text == null || text.length() > 100000) return;
            runOnUiThread(() -> {
                android.content.ClipboardManager manager=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
                manager.setPrimaryClip(android.content.ClipData.newPlainText("ImpulsaFit",text));
            });
        }
        @JavascriptInterface public void saveFile(String name, String text, String mime) {
            if (name==null || text==null || text.length()>6000000) { toast("El archivo no es válido."); return; }
            String safeName=name.replaceAll("[^A-Za-z0-9_.-]","_");
            if (safeName.length()==0 || safeName.length()>160) { toast("Nombre de archivo no válido."); return; }
            if (!"application/json".equals(mime) && !"text/calendar".equals(mime)) { toast("Formato de archivo no permitido."); return; }
            byte[] bytes=text.getBytes(StandardCharsets.UTF_8);
            // Preserve a private copy before opening the system's Save dialog.
            try {
                File dir=new File(getFilesDir(),"backups");
                if (!dir.isDirectory() && !dir.mkdirs()) throw new java.io.IOException();
                File file=new File(dir,safeName);
                try (FileOutputStream out=new FileOutputStream(file)) { out.write(bytes); }
                if ("application/json".equals(mime)) getPreferences(MODE_PRIVATE).edit().putString("lastBackup",safeName).apply();
            } catch (Exception e) { toast("No se pudo preparar la copia de seguridad."); return; }
            runOnUiThread(() -> chooseExport(safeName,bytes,mime));
        }
        @JavascriptInterface public void exportLastBackup() {
            String name=getPreferences(MODE_PRIVATE).getString("lastBackup",null);
            if (name==null) { toast("Todavía no hay una copia de seguridad guardada."); return; }
            try {
                File file=new File(new File(getFilesDir(),"backups"),name);
                if (file.length()>6000000) return;
                byte[] bytes=new byte[(int)file.length()];
                try (InputStream in=new FileInputStream(file)) {
                    int offset=0,n;
                    while (offset<bytes.length && (n=in.read(bytes,offset,bytes.length-offset))>0) offset+=n;
                }
                runOnUiThread(() -> chooseExport(name,bytes,"application/json"));
            } catch (Exception e) { toast("No se pudo recuperar la copia."); }
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request,result,data);
        if (request==IMPORT_FILE && importCallback!=null) {
            importCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));
            importCallback=null;
        }
        if (request==EXPORT_FILE) {
            byte[] bytes=exportBytes; String name=exportName;
            exportBytes=null; exportName=null;
            if (result!=RESULT_OK || data==null || data.getData()==null || bytes==null) return;
            try (OutputStream out=getContentResolver().openOutputStream(data.getData())) {
                if (out==null) throw new java.io.IOException();
                out.write(bytes);out.flush();toast("Archivo guardado: "+name);
            } catch (Exception e) { toast("No se pudo guardar el archivo. Conservas la copia dentro de la aplicación."); }
        }
    }
    @Override public void onBackPressed() {
        web.evaluateJavascript("(function(){var d=document.querySelector('dialog[open]');if(d){d.dispatchEvent(new Event('cancel',{cancelable:true}));return true;}return false;})()",value -> {
            if ("true".equals(value)) return;
            if (web.canGoBack()) web.goBack(); else finish();
        });
    }
    @Override protected void onPause() { if(web!=null)web.onPause();super.onPause(); }
    @Override protected void onResume() { super.onResume();if(web!=null)web.onResume(); }
    @Override protected void onDestroy() { if(importCallback!=null)importCallback.onReceiveValue(null);if(web!=null)web.destroy();super.onDestroy(); }
}
