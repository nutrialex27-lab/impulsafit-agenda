# ImpulsaFit Agenda

Agenda privada, instalable como PWA, para ImpulsaFit en Condes Wellness & Fitness (Huelva). No utiliza APIs de pago, automatizadores ni suscripciones externas.

## Funciones

- Agenda diaria, semanal y mensual; reservas de EMS, entrenamiento personal y demos.
- Clientes con teléfono internacional y permiso de contacto por WhatsApp.
- Reservas semanales de 2, 4, 8 o 12 sesiones y detección de solapamientos.
- Mensajes editables de reserva y recordatorio, con normativa y fecha límite para cancelar.
- WhatsApp mediante enlaces oficiales `wa.me`: el usuario pulsa Enviar y confirma manualmente en la agenda. No hay envíos automáticos ni confirmación de entrega.
- Plazos iniciales editables: recordatorio 48 horas antes y cancelación con 24 horas de antelación. Las reservas conservan una copia de sus condiciones originales.
- Datos guardados en D1 por cuenta autenticada. Control de versión para no sobrescribir cambios de otro dispositivo.
- Exportación/restauración JSON y exportación ICS con alarmas. ICS es una copia, no sincronización bidireccional; se debe verificar su importación y las notificaciones del calendario receptor.
- Manifest y service worker para instalar en navegadores compatibles. La agenda requiere conexión; no se guardan datos de clientes en cachés del service worker.
- El borrador de una reserva se conserva durante la sesión del navegador mientras se edita. Los registros se guardan al confirmar el formulario.

## Alcance

La agenda es del entrenador. No incluye autoservicio de reserva para clientes, cobros, gestión de bonos ni envíos programados de WhatsApp. Las cancelaciones se registran; el texto de normativa debe adaptarse a las condiciones previamente acordadas con los clientes.

## Verificación

`node --experimental-strip-types --test tests/agenda.test.mjs`

`node node_modules/typescript/bin/tsc --noEmit`

Pruebas: horario de Madrid y cambio estacional, solapamientos, plazos de recordatorio, condiciones históricas, teléfonos/enlaces, integridad de copias e ICS con líneas UTF-8 plegadas.

Los recursos de alojamiento se gestionan con la cuenta del propietario. La aplicación no contiene facturación ni integraciones con coste externo. No se promete disponibilidad perpetua o condiciones futuras de terceros.


## Edición descargable (coral)

`public/ImpulsaFit_Agenda.html` es la edición para abrir directamente en un navegador. Incluye el programa, los estilos y el icono en un solo archivo. No requiere servidor, cuenta ni instalación de dependencias para usarla. Los datos quedan en el almacenamiento del navegador de ese dispositivo. La edición web conserva el guardado por cuenta y la sincronización entre dispositivos.

Para trasladar datos, exporta una copia JSON desde Ajustes y restáurala en la otra edición. Las dos agendas no se sincronizan automáticamente. Para generar de nuevo el HTML después de editar el código: `npm ci` y `npm run build:portable`.

Los WhatsApp se preparan en la agenda; el usuario pulsa Enviar en WhatsApp. No hay envío automático.

El icono coral se entrega con nombres de archivo nuevos para que el navegador pueda detectar la actualización de identidad visual.


## Instalación de la agenda privada

El documento enlaza el manifiesto con `crossorigin="use-credentials"`, necesario para que Chrome lo recupere con la sesión en la edición privada. El enlace `/?instalar=1` abre directamente las instrucciones y el botón de instalación cuando el navegador emite `beforeinstallprompt`. Abre el enlace en Chrome (fuera del navegador interno de ChatGPT o WhatsApp), inicia sesión con la cuenta propietaria y utiliza Instalar y crear acceso directo → Instalar. El HTML descargable es una edición portátil, no el flujo de instalación PWA.


## Instalador Android independiente

La carpeta `android-app/` contiene el contenedor Android y las instrucciones para generar el APK firmado. Esta edición incluye la agenda local y se instala directamente en el móvil; consulta `android-app/README.md` para construcción, copias de seguridad y límites de la verificación. La firma se conserva por separado para permitir actualizar sin borrar los registros del dispositivo.


## Respuestas y normativa de Condes · 0.3.0

Configura tu WhatsApp de respuestas una sola vez. Los mensajes de reserva y recordatorio incluyen dos enlaces `wa.me` dirigidos a ese número: Confirmar y Cancelar. El cliente elige y pulsa Enviar en WhatsApp. No son botones interactivos de la API de Meta, no se envían solos y la agenda no lee las respuestas.

En la reserva, Cliente confirma / Cliente cancela permite registrar la respuesta con su hora de recepción real, para clasificar correctamente una cancelación anotada más tarde. Una reserva sin respuesta al vencer su plazo se muestra como confirmada sin respuesta; no se inventa una confirmación explícita del cliente. Marca Realizada o No acudió cuando corresponda. El cómputo de sesiones consumidas suma realizadas, ausencias y cancelaciones fuera de plazo, sin gestionar un saldo de bonos.

Los mensajes identifican las normas como normativa de Condes Wellness & Fitness y explican que el silencio no cancela la reserva; una ausencia sin cancelación a tiempo consume sesión. Se conserva el plazo de cada reserva. La plantilla original de la versión anterior se actualiza al preparar nuevos mensajes; los textos personalizados se preservan. Las copias anteriores son compatibles y la actualización Android conserva paquete y firma.
