import { NextResponse } from 'next/server';
import { getChatGPTUser } from '../../chatgpt-auth';
import { getDb } from '../../../db';
import { agendas } from '../../../db/schema';
import { and, eq } from 'drizzle-orm';
import { emptyState, validateAgenda } from '../../../lib/agenda-model';
export const dynamic='force-dynamic';
const reply=(body:unknown,status=200)=>NextResponse.json(body,{status,headers:{'Cache-Control':'private, no-store'}});
export async function GET(){
  const user=await getChatGPTUser();if(!user)return reply({error:'Inicia sesión para acceder a tu agenda.'},401);
  try { const row=await getDb().select().from(agendas).where(eq(agendas.ownerId,user.userId)).get();return reply({state:row?JSON.parse(row.payload):emptyState(),revision:row?.revision??0}); }
  catch {return reply({error:'No se ha podido cargar la agenda. Vuelve a intentarlo.'},503);}
}
export async function PUT(request:Request){
  const user=await getChatGPTUser();if(!user)return reply({error:'Inicia sesión para guardar tu agenda.'},401);
  const origin=request.headers.get('origin');
  if(origin&&origin!==new URL(request.url).origin)return reply({error:'Origen no permitido.'},403);
  if(Number(request.headers.get('content-length')??0)>6_000_000)return reply({error:'La agenda supera el tamaño permitido.'},413);
  try {
    const raw=await request.text();if(raw.length>6_000_000)return reply({error:'La agenda supera el tamaño permitido.'},413);
    const body=JSON.parse(raw);if(!Number.isSafeInteger(body.revision)||body.revision<0)return reply({error:'Versión no válida.'},400);
    const state=validateAgenda(body.state), db=getDb(),updatedAt=new Date().toISOString();
    const row=body.revision===0
      ?await db.insert(agendas).values({ownerId:user.userId,payload:JSON.stringify(state),revision:1,updatedAt}).onConflictDoNothing().returning({revision:agendas.revision}).get()
      :await db.update(agendas).set({payload:JSON.stringify(state),revision:body.revision+1,updatedAt}).where(and(eq(agendas.ownerId,user.userId),eq(agendas.revision,body.revision))).returning({revision:agendas.revision}).get();
    if(!row)return reply({error:'La agenda cambió en otro dispositivo. Cierra este formulario y actualiza antes de volver a guardar.'},409);
    return reply({revision:row.revision,updatedAt});
  }catch(error){
    const e=error as Error;
    if(e.name==='ZodError'||e instanceof SyntaxError)return reply({error:'Revisa los datos: la agenda o la copia no tiene un formato válido.'},400);
    if(e.message.includes('horario')||e.message.includes('copia')||e.message.includes('cliente')||e.message.includes('teléfono'))return reply({error:e.message},400);
    return reply({error:'No se ha podido guardar. Tus cambios siguen en el formulario; vuelve a intentarlo.'},503);
  }
}
