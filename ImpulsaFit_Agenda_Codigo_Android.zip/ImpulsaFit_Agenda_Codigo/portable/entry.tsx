import {createRoot} from 'react-dom/client';
import Agenda from '../app/agenda';
createRoot(document.getElementById('root')!).render(<Agenda/>);
