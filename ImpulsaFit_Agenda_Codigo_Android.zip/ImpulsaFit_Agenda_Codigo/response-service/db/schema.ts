import {sqliteTable,text,integer,index} from 'drizzle-orm/sqlite-core';
export const reservations=sqliteTable('reservation_responses',{
 tokenHash:text('token_hash').primaryKey(),ownerHash:text('owner_hash').notNull(),version:text('version').notNull(),
 details:text('details').notNull(),startMs:integer('start_ms').notNull(),deadlineMs:integer('deadline_ms').notNull(),
 expiresMs:integer('expires_ms').notNull(),closed:integer('closed').notNull().default(0),
 choice:text('choice'),receivedAt:text('received_at'),revision:integer('revision').notNull().default(0),
},t=>[index('reservation_expiry').on(t.expiresMs)]);
export const rateLimits=sqliteTable('response_rate_limits',{
 bucket:text('bucket').primaryKey(),count:integer('count').notNull(),expiresMs:integer('expires_ms').notNull(),
},t=>[index('response_rate_expiry').on(t.expiresMs)]);
