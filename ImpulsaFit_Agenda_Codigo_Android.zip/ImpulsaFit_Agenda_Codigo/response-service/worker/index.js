const HEX=/^[a-f0-9]{64}$/;
const VERSION=/^[A-Za-z0-9_-]{8,100}$/;
const CENTER='Condes Wellness & Fitness';
const DAY=86400000;
const headers={'Cache-Control':'no-store, private','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff','X-Robots-Tag':'noindex, nofollow, noarchive','Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type','Access-Control-Max-Age':'600'};
class Failure extends Error {constructor(message,status=400){super(message);this.status=status;}}
export async function hash(value){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)))].map(x=>x.toString(16).padStart(2,'0')).join('');}
const json=(value,status=200)=>new Response(JSON.stringify(value),{status,headers:{...headers,'Content-Type':'application/json; charset=utf-8'}});
const validKey=value=>typeof value==='string'&&HEX.test(value);
function requireKeys(body){if(!validKey(body.token)||!validKey(body.editKey))throw new Failure('Enlace o acceso no válido.');}
async function bodyOf(request){
 if(Number(request.headers.get('content-length')||0)>60000)throw new Failure('La solicitud es demasiado grande.',413);
 const text=await request.text();if(text.length>60000)throw new Failure('La solicitud es demasiado grande.',413);
 try{const body=JSON.parse(text);if(!body||typeof body!=='object'||Array.isArray(body))throw 0;return body;}catch{throw new Failure('Solicitud no válida.');}
}
async function limit(env,request,kind,now){
 const window=kind==='publish'?3600000:60000,max=kind==='publish'?120:kind==='respond'?60:180;
 const ip=request.headers.get('cf-connecting-ip')||'unknown';
 const bucket=await hash(kind+'|'+ip+'|'+Math.floor(now/window));
 const result=await env.DB.prepare('INSERT INTO response_rate_limits(bucket,count,expires_ms) VALUES(?,1,?) ON CONFLICT(bucket) DO UPDATE SET count=count+1 RETURNING count').bind(bucket,now+window*2).first();
 if(result.count>max)throw new Failure('Demasiadas solicitudes. Inténtalo de nuevo dentro de unos minutos.',429);
}
async function cleanup(env,now){await env.DB.batch([
 env.DB.prepare('DELETE FROM reservation_responses WHERE token_hash IN (SELECT token_hash FROM reservation_responses WHERE expires_ms < ? LIMIT 50)').bind(now),
 env.DB.prepare('DELETE FROM response_rate_limits WHERE bucket IN (SELECT bucket FROM response_rate_limits WHERE expires_ms < ? LIMIT 100)').bind(now),
]);}
const ownerView=row=>({version:row.version,choice:row.choice,receivedAt:row.received_at,revision:row.revision,closed:!!row.closed});
const clientView=(row,now)=>({...ownerView(row),details:JSON.parse(row.details),deadline:new Date(row.deadline_ms).toISOString(),serverNow:new Date(now).toISOString(),expired:now>=row.start_ms,late:now>row.deadline_ms});
async function getRow(env,token){return env.DB.prepare('SELECT * FROM reservation_responses WHERE token_hash=?').bind(await hash(token)).first();}
function validateDetails(body,now){
 const d=body.details;
 if(!d||!VERSION.test(body.version)||!Number.isInteger(d.duration)||d.duration<10||d.duration>240||!Number.isInteger(d.cancelHours)||d.cancelHours<0||d.cancelHours>168)throw new Failure('Revisa los datos de la sesión.');
 const start=Date.parse(d.start);
 if(!Number.isFinite(start)||start<=now||start>now+366*DAY)throw new Failure('Solo se pueden activar enlaces para sesiones futuras, hasta un año.');
 for(const [key,max] of [['business',100],['location',250],['policy',2000]])if(typeof d[key]!=='string'||d[key].length>max)throw new Failure('Datos de reserva no válidos.');
 if(!['ems','personal','demo'].includes(d.service))throw new Failure('Tipo de sesión no válido.');
 // The public record deliberately excludes client IDs, names, phones and notes.
 return {start:new Date(start).toISOString(),duration:d.duration,cancelHours:d.cancelHours,business:d.business,location:d.location,service:d.service,policy:d.policy,center:CENTER};
}
async function publish(request,env,body,now){
 requireKeys(body);await limit(env,request,'publish',now);
 const tokenHash=await hash(body.token),ownerHash=await hash(body.editKey),old=await getRow(env,body.token);
 if(old&&old.owner_hash!==ownerHash)throw new Failure('No tienes acceso para editar esta reserva.',403);
 if(body.close){
  if(old)await env.DB.prepare('UPDATE reservation_responses SET closed=1 WHERE token_hash=? AND owner_hash=?').bind(tokenHash,ownerHash).run();
  return json(old?ownerView({...old,closed:1}):{closed:true,revision:0,version:body.version});
 }
 const d=validateDetails(body,now),start=Date.parse(d.start),deadline=start-d.cancelHours*3600000;
 if(old&&old.version===body.version){
  if(old.closed)throw new Failure('Este enlace está cerrado. Guarda de nuevo la reserva para crear otra versión.',409);
  if(old.details!==JSON.stringify(d))throw new Failure('La reserva ha cambiado. Guarda los cambios antes de compartirla.',409);
  return json(ownerView(old));
 }
 if(old){
  await env.DB.prepare('UPDATE reservation_responses SET version=?,details=?,start_ms=?,deadline_ms=?,expires_ms=?,closed=0,choice=NULL,received_at=NULL,revision=0 WHERE token_hash=? AND owner_hash=?').bind(body.version,JSON.stringify(d),start,deadline,start+60*DAY,tokenHash,ownerHash).run();
 }else{
  await env.DB.prepare('INSERT INTO reservation_responses(token_hash,owner_hash,version,details,start_ms,deadline_ms,expires_ms) VALUES(?,?,?,?,?,?,?) ON CONFLICT(token_hash) DO NOTHING').bind(tokenHash,ownerHash,body.version,JSON.stringify(d),start,deadline,start+60*DAY).run();
 }
 const saved=await getRow(env,body.token);
 if(saved.owner_hash!==ownerHash)throw new Failure('No tienes acceso para editar esta reserva.',403);
 await cleanup(env,now);return json(ownerView(saved));
}
async function sync(request,env,body,now){
 if(!Array.isArray(body.items)||body.items.length>60)throw new Failure('Lote de reservas no válido.');
 await limit(env,request,'sync',now);
 const items=await Promise.all(body.items.map(async item=>{requireKeys(item);return {...item,tokenHash:await hash(item.token),ownerHash:await hash(item.editKey)};}));
 if(!items.length)return json({items:[]});
 const rows=await env.DB.batch(items.map(x=>env.DB.prepare('SELECT version,choice,received_at,revision,closed,owner_hash FROM reservation_responses WHERE token_hash=?').bind(x.tokenHash)));
 return json({items:rows.map((result,i)=>{const row=result.results?.[0];return row&&row.owner_hash===items[i].ownerHash?{token:items[i].token,...ownerView(row)}:{token:items[i].token,error:'not_found'};})});
}
async function publicAction(request,env,body,now,respond){
 if(request.headers.get('origin')!==new URL(request.url).origin)throw new Failure('Abre el enlace de la reserva para responder.',403);
 if(!validKey(body.token))throw new Failure('El enlace no es válido.',404);
 await limit(env,request,respond?'respond':'view',now);let row=await getRow(env,body.token);
 if(!row||row.expires_ms<now)throw new Failure('Este enlace ya no está disponible. Contacta con el centro.',404);
 if(!respond)return json(clientView(row,now));
 if(row.closed||now>=row.start_ms)throw new Failure('Esta sesión ya no admite respuestas. Contacta con el centro.',410);
 if(body.version!==row.version)throw new Failure('La sesión ha cambiado. Revisa los datos antes de responder.',409);
 if(!['confirmed','cancelled'].includes(body.choice))throw new Failure('Elige Confirmar o Cancelar.');
 if(row.choice==='cancelled'&&body.choice==='confirmed')throw new Failure('La sesión ya está cancelada. Contacta con el centro para reservar de nuevo.',409);
 await env.DB.prepare("UPDATE reservation_responses SET choice=?,received_at=?,revision=revision+1 WHERE token_hash=? AND version=? AND closed=0 AND start_ms>? AND COALESCE(choice,'')!='cancelled' AND COALESCE(choice,'')!=?").bind(body.choice,new Date(now).toISOString(),await hash(body.token),body.version,now,body.choice).run();
 row=await getRow(env,body.token);
 if(row.version!==body.version||row.closed)throw new Failure('La sesión ha cambiado. Revisa el enlace antes de responder.',409);
 return json(clientView(row,now));
}
export async function handle(request,env,now=Date.now()){
 try{
  const path=new URL(request.url).pathname;
  if(path==='/health'&&request.method==='GET')return json({ok:true,version:'1'});
  if((path==='/'||path==='/r')&&request.method==='GET')return page();
  if(request.method==='OPTIONS'&&path.startsWith('/api/'))return new Response(null,{status:204,headers});
  if(!['/api/publish','/api/sync','/api/view','/api/respond'].includes(path)||request.method!=='POST')return json({error:'Ruta no disponible.'},404);
  if(!env.DB)throw new Failure('El servicio no está disponible. Inténtalo de nuevo.',503);
  const body=await bodyOf(request);
  if(path==='/api/publish')return await publish(request,env,body,now);
  if(path==='/api/sync')return await sync(request,env,body,now);
  return await publicAction(request,env,body,now,path==='/api/respond');
 }catch(e){return json({error:e instanceof Failure?e.message:'No se pudo guardar la respuesta. Inténtalo de nuevo.',retryable:!(e instanceof Failure)||e.status>=500},e instanceof Failure?e.status:503);}
}
export default {fetch(request,env){return handle(request,env);}};
function page(){
 const nonce=crypto.randomUUID();
 const html=`<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><meta name="theme-color" content="#F16B40"><title>Tu sesión · Condes Wellness & Fitness</title><style>
 :root{font-family:system-ui,-apple-system,sans-serif;color:#19313f;background:#f3f5f8;font-size:16px}*{box-sizing:border-box}body{margin:0;padding:24px 16px 48px}main{width:100%;max-width:520px;margin:0 auto}header{display:flex;align-items:center;gap:12px;margin:12px 0 32px}.logo{width:52px;height:52px;border-radius:16px;background:#f16b40;display:grid;place-items:center;color:white;font-size:26px}header strong{display:block;letter-spacing:.12em;font-size:1.05rem}header small{font-size:.875rem;color:#52656e}article{background:white;border:1px solid #dce3e8;border-radius:24px;padding:28px 24px;box-shadow:0 12px 40px #19313f08}h1{font-size:1.9rem;line-height:1.2;letter-spacing:-.03em;margin:0 0 16px}p{line-height:1.6;margin:0 0 16px}.subtle{color:#52656e}.details{display:grid;gap:10px;margin:24px 0;padding:20px;background:#f5f8fa;border-radius:16px}.details strong{font-size:1.1rem}.policy{border-top:1px solid #dce3e8;padding-top:22px;margin-top:24px}.policy h2{font-size:1.05rem;margin:0 0 10px}.policy p{font-size:.95rem;white-space:pre-line}.deadline{font-size:.95rem;font-weight:650}.actions{display:grid;gap:12px;margin-top:24px}button{font:inherit;font-weight:700;border:0;border-radius:14px;padding:17px 16px;min-height:56px;cursor:pointer;background:#13755f;color:white;width:100%}.cancel{background:#fff1ec;color:#a13e23;border:1px solid #edc9bc}button:disabled{opacity:.5;cursor:default}.result{padding:16px;background:#e8f6ef;border-radius:14px;font-weight:650}.result.cancelled{background:#fff1ec;color:#9b3f29}.error{padding:16px;background:#fff1ec;color:#9b3f29;border-radius:14px;margin-top:16px}.help{font-size:.875rem;color:#52656e;margin-top:24px}footer{font-size:.875rem;color:#52656e;text-align:center;padding:24px 8px}[hidden]{display:none!important}button:focus-visible{outline:3px solid #f16b40;outline-offset:3px}@media(max-width:380px){article{padding:24px 18px}h1{font-size:1.65rem}}
 </style></head><body><main><header><span class="logo" aria-hidden="true">✓</span><div><strong>CONDES</strong><small>Wellness & Fitness · Reservas ImpulsaFit</small></div></header><article><h1>Tu próxima sesión</h1><p id="intro" class="subtle">Abre el enlace que has recibido para confirmar o cancelar tu reserva.</p><div id="booking" hidden><div class="details"><strong id="date"></strong><span id="time"></span><span id="service"></span><span id="location"></span></div><div id="result" role="status" hidden></div><section class="policy"><h2>Normativa de Condes Wellness & Fitness</h2><p id="policy"></p><p id="deadline" class="deadline"></p><p id="late" class="deadline"></p></section><div class="actions"><button id="confirm">Confirmar sesión</button><button id="cancel" class="cancel">Cancelar sesión</button></div><p class="help">Tu elección se guarda directamente en la agenda del centro. No tienes que enviar otro WhatsApp. Una cancelación registrada no puede deshacerse desde este enlace.</p></div><p id="error" class="error" role="alert" hidden></p><button id="retry" class="cancel" hidden>Volver a cargar</button></article><footer>Este enlace permite gestionar únicamente esta reserva.<br>Compártelo solo con la persona que tiene la cita.</footer></main><script nonce="${nonce}">
 const token=location.hash.slice(1),el=id=>document.getElementById(id);let current=null,pending=false,loadedAt=0;
 const fullDate=v=>new Intl.DateTimeFormat('es-ES',{weekday:'long',day:'numeric',month:'long',year:'numeric',timeZone:'Europe/Madrid'}).format(new Date(v)),hour=v=>new Intl.DateTimeFormat('es-ES',{hour:'2-digit',minute:'2-digit',hourCycle:'h23',timeZone:'Europe/Madrid'}).format(new Date(v));
 async function api(path,body){const response=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),credentials:'omit',cache:'no-store'});const data=await response.json();if(!response.ok){const error=new Error(data.error||'No se pudo guardar la respuesta.');error.status=response.status;throw error;}return data;}
 function render(){if(!current)return;const d=current.details,now=Date.parse(current.serverNow)+(performance.now()-loadedAt),late=now>Date.parse(current.deadline),closed=current.closed||now>=Date.parse(d.start);el('booking').hidden=false;el('intro').textContent='Revisa tu cita y elige una de las dos opciones.';el('date').textContent=fullDate(d.start);el('time').textContent=hour(d.start)+' · '+d.duration+' minutos · Hora de Madrid';el('service').textContent={ems:'EMS',personal:'Entrenamiento personal',demo:'Demo EMS'}[d.service];el('location').textContent=d.location;el('policy').textContent=d.policy;el('deadline').textContent='Límite para cancelar sin consumir sesión: '+fullDate(current.deadline)+' a las '+hour(current.deadline)+'.';el('late').textContent=closed?'Esta sesión ya no admite cambios desde el enlace.':late?'El plazo de cancelación ha vencido. Cancelar ahora consume una sesión de tu bono.':'Si cancelas antes del límite, no consumirás sesión de tu bono.';el('confirm').disabled=pending||closed||!!current.choice;el('cancel').disabled=pending||closed||current.choice==='cancelled';el('cancel').textContent=late?'Cancelar sesión · consume sesión':'Cancelar sesión';const r=el('result');r.hidden=!current.choice&&!closed;if(closed){r.className='result';r.textContent='Reserva cerrada. Contacta con el centro si necesitas ayuda.';}else if(current.choice){r.className='result '+current.choice;r.textContent=current.choice==='confirmed'?'Sesión confirmada. Tu respuesta ya está registrada.':Date.parse(current.receivedAt)>Date.parse(current.deadline)?'Sesión cancelada fuera de plazo. Cuenta como una sesión consumida.':'Sesión cancelada en plazo. No consume sesión de tu bono.';}}
 async function load(){el('error').hidden=true;el('retry').hidden=true;if(!/^[a-f0-9]{64}$/.test(token)){el('intro').textContent='Este enlace no contiene una reserva válida. Usa el enlace completo que has recibido por WhatsApp.';return;}try{el('intro').textContent='Cargando tu reserva…';current=await api('/api/view',{token});loadedAt=performance.now();render();}catch(error){el('intro').textContent='No se ha podido cargar la reserva.';el('error').textContent=error.message;el('error').hidden=false;el('retry').hidden=false;}}
 async function respond(choice){if(pending||!current)return;pending=true;el('error').hidden=true;render();try{current=await api('/api/respond',{token,version:current.version,choice});loadedAt=performance.now();}catch(error){el('error').textContent=error.message;el('error').hidden=false;el('retry').hidden=false;if(error.status===409)await load();}finally{pending=false;render();}}
 el('confirm').onclick=()=>respond('confirmed');el('cancel').onclick=()=>respond('cancelled');el('retry').onclick=load;setInterval(render,1000);load();
 </script></body></html>`;
 return new Response(html,{headers:{...headers,'Content-Type':'text/html; charset=utf-8','Content-Security-Policy':`default-src 'none'; script-src 'nonce-${nonce}'; style-src 'unsafe-inline'; connect-src 'self'; img-src data:; base-uri 'none'; form-action 'self'; frame-ancestors 'none'`}});
}
