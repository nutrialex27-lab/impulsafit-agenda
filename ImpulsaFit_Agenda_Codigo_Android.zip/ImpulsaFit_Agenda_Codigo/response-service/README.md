# Respuestas de reservas · Condes / ImpulsaFit

Servicio para confirmar o cancelar una sesión desde un enlace individual. La agenda de clientes no se publica. No utiliza la API de WhatsApp, envíos automáticos ni suscripciones externas. Depende de la disponibilidad y los límites del alojamiento de la cuenta; no se promete disponibilidad o gratuidad perpetua de terceros.

La aplicación conserva nombres, teléfonos, notas y claves de edición en su almacenamiento privado. El servicio recibe solamente fecha, duración, tipo de sesión, ubicación pública y normativa de la reserva enlazada. Almacena hashes SHA-256 de dos valores aleatorios de 256 bits: acceso del cliente y edición del propietario. La clave de edición no aparece en el enlace público. Las copias JSON privadas de la app incluyen esos accesos para poder restaurar la gestión de las reservas.

La página /r usa el fragmento del enlace y una petición POST para cargar la cita. GET y vistas previas no cambian su estado. El cliente pulsa Confirmar o Cancelar; la hora válida es la del servidor. Las cancelaciones son terminales para el cliente, y el propietario puede reprogramar creando una nueva versión. Las respuestas a una versión anterior se rechazan. Repetir una respuesta no cambia su fecha original. No hay endpoint de listado público.

Se aplican límites de tamaño y frecuencia. Los identificadores de los límites son hashes temporales, no direcciones IP almacenadas en claro. Los registros de citas caducan a los 60 días de su inicio; la limpieza se ejecuta en lotes acotados al publicar reservas nuevas.

La app consulta respuestas con conexión mientras está abierta o al recuperar el foco. No hay notificaciones push ni recepción en segundo plano garantizada. Los cambios y revocaciones hechos sin conexión se envían cuando la app vuelve a conectarse.

## Desarrollo

`npm install`, `npm run db:generate` si cambia el esquema, `npm test`, `npm run build` y `node scripts/validate-artifact.mjs`.

Las migraciones generadas en .openai/drizzle se incluyen en el artefacto. Las tablas no se crean durante solicitudes. Las pruebas usan SQLite real en memoria con el mismo SQL de migraciones.
