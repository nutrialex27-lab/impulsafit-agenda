CREATE TABLE `response_rate_limits` (
	`bucket` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL,
	`expires_ms` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `response_rate_expiry` ON `response_rate_limits` (`expires_ms`);--> statement-breakpoint
CREATE TABLE `reservation_responses` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`owner_hash` text NOT NULL,
	`version` text NOT NULL,
	`details` text NOT NULL,
	`start_ms` integer NOT NULL,
	`deadline_ms` integer NOT NULL,
	`expires_ms` integer NOT NULL,
	`closed` integer DEFAULT 0 NOT NULL,
	`choice` text,
	`received_at` text,
	`revision` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE INDEX `reservation_expiry` ON `reservation_responses` (`expires_ms`);