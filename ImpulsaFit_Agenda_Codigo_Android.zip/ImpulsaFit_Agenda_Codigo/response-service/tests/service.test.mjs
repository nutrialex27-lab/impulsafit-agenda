import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {handle,hash} from '../worker/index.js';
const origin='https://reservas.example',now=Date.parse('2026-11-25T08:00:00.000Z');
function database(){
 const db=new DatabaseSync(':memory:');for(const file of readdirSync('.openai/drizzle').filter(x=>x.endsWith('.sql')))db.exec(readFileSync('.openai/drizzle/'+file,'utf8'));
 function prepare(sql){let args=[];return {bind(...v){args=v;return this;},async first(){return db.prepare(sql).get(...args)??null;},async run(){const r=db.prepare(sql).run(...args);return {success:true,meta:{changes:Number(r.changes)}};},async all(){return {results:db.prepare(sql).all(...args)};},sql,args:()=>args};}
 return {raw:db,DB:{prepare,async batch(items){const results=[];db.exec('BEGIN');try{for(const x of items)results.push(/^\s*SELECT/i.test(x.sql)?{results:db.prepare(x.sql).all(...x.args())}:{results:[],meta:{changes:Number(db.prepare(x.sql).run(...x.args()).changes)}});db.exec('COMMIT');return results;}catch(e){db.exec('ROLLBACK');throw e;}}}};
}
const payload=(n='a')=>({token:n.repeat(64),editKey:'e'.repeat(64),version:'version-0001',details:{start:'2026-11-26T09:00:00.000Z',duration:35,service:'ems',cancelHours:24,business:'ImpulsaFit',location:'Condes · Huelva',policy:'Sin respuesta, reserva confirmada. Cancelar tarde consume sesión.'}});
async function call(env,path,body,time=now,headers={}){const r=await handle(new Request(origin+path,{method:'POST',headers:{'Content-Type':'application/json',origin,...headers},body:JSON.stringify(body)}),env,time);return {status:r.status,body:await r.json()};}
test('publishing stores hashed capabilities and only appointment details, never client PII',async()=>{
 const env=database(),p=payload();p.details.phone='+34600000000';p.details.name='Not for the public service';
 assert.equal((await call(env,'/api/publish',p)).status,200);const row=env.raw.prepare('SELECT * FROM reservation_responses').get();
 assert.equal(row.token_hash,await hash(p.token));assert.equal(row.owner_hash,await hash(p.editKey));assert.ok(!row.details.includes('phone')&&!row.details.includes('Not for'));
 const view=await call(env,'/api/view',{token:p.token});assert.equal(view.status,200);assert.equal(view.body.choice,null);assert.equal(view.body.editKey,undefined);assert.equal(view.body.owner_hash,undefined);
});
test('opening a link or preview does not change attendance; explicit POST does',async()=>{
 const env=database(),p=payload();await call(env,'/api/publish',p);
 const page=await handle(new Request(origin+'/r#'+p.token),env,now);assert.equal(page.status,200);assert.match(page.headers.get('Content-Security-Policy'),/nonce-/);assert.equal(page.headers.get('Referrer-Policy'),'no-referrer');
 const get=await handle(new Request(origin+'/api/respond?choice=cancelled'),env,now);assert.equal(get.status,404);
 assert.equal((await call(env,'/api/view',{token:p.token})).body.revision,0);
 const response=await call(env,'/api/respond',{token:p.token,version:p.version,choice:'confirmed'});assert.equal(response.status,200);assert.equal(response.body.choice,'confirmed');assert.equal(response.body.receivedAt,new Date(now).toISOString());
 const synced=await call(env,'/api/sync',{items:[{token:p.token,editKey:p.editKey}]});assert.equal(synced.body.items[0].choice,'confirmed');assert.equal(synced.body.items[0].revision,1);
});
test('private edit keys are required, and public callers cannot enumerate or overwrite another booking',async()=>{
 const env=database(),p=payload();await call(env,'/api/publish',p);
 assert.equal((await call(env,'/api/publish',{...p,editKey:'b'.repeat(64),close:true})).status,403);
 const sync=await call(env,'/api/sync',{items:[{token:p.token,editKey:'b'.repeat(64)}]});assert.deepEqual(sync.body.items[0],{token:p.token,error:'not_found'});
 assert.equal((await call(env,'/api/view',{token:'c'.repeat(64)})).status,404);
 assert.equal((await call(env,'/api/respond',{token:p.token,version:p.version,choice:'cancelled'},now,{origin:'https://another.example'})).status,403);
});
test('server timestamps classify cancellation; repeated requests preserve the original time',async()=>{
 const env=database(),p=payload();await call(env,'/api/publish',p);const cutoff=Date.parse(p.details.start)-86400000;
 const r=await call(env,'/api/respond',{token:p.token,version:p.version,choice:'cancelled'},cutoff);assert.equal(r.body.receivedAt,new Date(cutoff).toISOString());
 const again=await call(env,'/api/respond',{token:p.token,version:p.version,choice:'cancelled'},cutoff+60000);assert.equal(again.body.receivedAt,r.body.receivedAt);assert.equal(again.body.revision,1);
 assert.equal((await call(env,'/api/respond',{token:p.token,version:p.version,choice:'confirmed'},cutoff+60000)).status,409);
 const other=payload('b');await call(env,'/api/publish',other);const late=await call(env,'/api/respond',{token:other.token,version:other.version,choice:'cancelled'},cutoff+1);assert.ok(Date.parse(late.body.receivedAt)>Date.parse(late.body.deadline));
});
test('confirmed clients can cancel; sending another reminder never clears their response',async()=>{
 const env=database(),p=payload();await call(env,'/api/publish',p);await call(env,'/api/respond',{token:p.token,version:p.version,choice:'confirmed'});
 assert.equal((await call(env,'/api/publish',p)).body.choice,'confirmed');
 assert.equal((await call(env,'/api/respond',{token:p.token,version:p.version,choice:'cancelled'},now+1000)).body.revision,2);
 assert.equal((await call(env,'/api/publish',p)).body.choice,'cancelled');
});
test('rescheduling rejects stale responses; closing prevents new answers',async()=>{
 const env=database(),p=payload();await call(env,'/api/publish',p);const updated={...p,version:'version-0002',details:{...p.details,start:'2026-11-27T09:00:00.000Z'}};
 assert.equal((await call(env,'/api/publish',updated)).status,200);
 assert.equal((await call(env,'/api/respond',{token:p.token,version:p.version,choice:'confirmed'})).status,409);
 assert.equal((await call(env,'/api/publish',{...updated,close:true})).status,200);
 assert.equal((await call(env,'/api/respond',{token:p.token,version:updated.version,choice:'confirmed'})).status,410);
});
test('responses after the session starts and unavailable persistence never report success',async()=>{
 const env=database(),p=payload();await call(env,'/api/publish',p);
 assert.equal((await call(env,'/api/respond',{token:p.token,version:p.version,choice:'confirmed'},Date.parse(p.details.start))).status,410);
 assert.equal((await call({},'/api/respond',{token:p.token,version:p.version,choice:'confirmed'})).status,503);
 assert.equal((await call(env,'/api/sync',{items:Array(61).fill({})})).status,400);
});
