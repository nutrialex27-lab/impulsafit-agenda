import {z} from 'zod';
import {type Appointment,type AgendaState,isActive,policyText,recordClientResponse} from './agenda-model.ts';
export const RESPONSE_ORIGIN='https://impulsafit-respuestas.nutrialex-27.chatgpt.site';
const randomKey=()=>Array.from(crypto.getRandomValues(new Uint8Array(32)),n=>n.toString(16).padStart(2,'0')).join('');
export const newOnline=():NonNullable<Appointment['online']>=>({token:randomKey(),editKey:randomKey(),version:randomKey(),published:false,dirty:true,closed:false,remoteRevision:0});
export const onlineLink=(a:Appointment)=>a.online?.published&&!a.online.dirty&&!a.online.closed?RESPONSE_ORIGIN+'/r#'+a.online.token:'';
const snapshot=(a:Appointment)=>JSON.stringify([a.start,a.duration,a.service,a.clientId,a.terms.business,a.terms.location,a.terms.cancelHours,policyText(a)]);
export function reconcileOnline(next:AgendaState,previous:AgendaState|null):AgendaState {
 if(!previous)return next;
 const old=new Map(previous.appointments.map(a=>[a.id,a]));
 const appointments=next.appointments.map(a=>{
  const before=old.get(a.id);
  if(!a.online||!before?.online||a.online.token!==before.online.token)return a;
  const changed=snapshot(a)!==snapshot(before)||(isActive(a)&&!isActive(before));
  if(changed)return {...a,online:{...a.online,version:randomKey(),dirty:true,closed:false,remoteRevision:0}};
  if(isActive(a)!==isActive(before))return {...a,online:{...a.online,dirty:true}};
  return a;
 });
 const remaining=new Set(appointments.map(a=>a.id));
 const revoked=[...(next.onlineRevocations??[])];
 for(const a of previous.appointments)if(!remaining.has(a.id)&&a.online?.published&&!revoked.some(x=>x.token===a.online!.token))revoked.push({token:a.online.token,editKey:a.online.editKey,version:a.online.version});
 return {...next,appointments,onlineRevocations:revoked};
}
const resultSchema=z.object({version:z.string(),choice:z.enum(['confirmed','cancelled']).nullable().optional(),receivedAt:z.string().datetime().nullable().optional(),revision:z.number().int().nonnegative(),closed:z.boolean()});
export type OnlineResult=z.infer<typeof resultSchema>;
export function mergeOnline(a:Appointment,result:OnlineResult):Appointment {
 const r=resultSchema.parse(result);
 if(!a.online||a.online.version!==r.version)return a;
 let updated:Appointment={...a,online:{...a.online,published:true,dirty:false,closed:r.closed,remoteRevision:Math.max(a.online.remoteRevision,r.revision)}};
 if(isActive(a)&&r.revision>a.online.remoteRevision&&r.choice&&r.receivedAt)updated=recordClientResponse(updated,r.choice,r.receivedAt,'online');
 return updated;
}
async function request(path:string,body:unknown){
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);
 try{
  const r=await fetch(RESPONSE_ORIGIN+path,{method:'POST',credentials:'omit',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:controller.signal});
  const j:unknown=await r.json();if(!r.ok){const error=z.object({error:z.string().optional()}).safeParse(j);throw Error(error.success&&error.data.error||'No se ha podido conectar con las respuestas de tus reservas.');}return j;
 }catch(e){throw Error(e instanceof Error&&e.name!=='AbortError'?e.message:'No se ha podido conectar. Revisa Internet y vuelve a intentarlo.');}finally{clearTimeout(timer);}
}
export async function publishOnline(a:Appointment){
 if(!a.online)throw Error('Falta preparar el enlace de esta reserva.');
 const body={token:a.online.token,editKey:a.online.editKey,version:a.online.version,close:!isActive(a),details:{start:a.start,duration:a.duration,service:a.service,business:a.terms.business,location:a.terms.location,cancelHours:a.terms.cancelHours,policy:policyText(a)}};
 return resultSchema.parse(await request('/api/publish',body));
}
export async function revokeOnline(items:AgendaState['onlineRevocations']){
 const successful:string[]=[];for(const item of items){await request('/api/publish',{...item,close:true});successful.push(item.token);}return successful;
}
export async function fetchOnline(appointments:Appointment[]){
 const results=new Map<string,OnlineResult>();
 for(let offset=0;offset<appointments.length;offset+=60){
  const items=appointments.slice(offset,offset+60).filter(a=>a.online).map(a=>({token:a.online!.token,editKey:a.online!.editKey}));
  const j=z.object({items:z.array(z.object({token:z.string(),error:z.string().optional()}).passthrough())}).parse(await request('/api/sync',{items}));
  for(const item of j.items)if(!item.error)results.set(item.token,resultSchema.parse(item));
 }
 return results;
}
