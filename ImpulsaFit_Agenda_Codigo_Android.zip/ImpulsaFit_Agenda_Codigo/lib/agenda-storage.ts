import { emptyState, validateAgenda } from './agenda-model';

declare const __IF_AGENDA_PORTABLE__: boolean;
export const isPortable = typeof __IF_AGENDA_PORTABLE__ !== 'undefined' && __IF_AGENDA_PORTABLE__;
const KEY = 'impulsafit-agenda-portable-v1';
const response = (body: unknown, status = 200) => new Response(JSON.stringify(body), {status, headers: {'Content-Type':'application/json'}});

// The downloadable edition uses this device's browser storage; the hosted
// edition keeps its existing authenticated API and cross-device persistence.
export async function agendaFetch(url: string, init?: RequestInit): Promise<Response> {
  if (!isPortable) return fetch(url, init);
  try {
    const raw = localStorage.getItem(KEY);
    const saved = raw ? JSON.parse(raw) : {state: emptyState(), revision: 0};
    const state = validateAgenda(saved.state);
    if (!Number.isSafeInteger(saved.revision) || saved.revision < 0) throw new Error('Copia local no válida.');
    if (init?.method !== 'PUT') {
      // Detect a browser that blocks saving before allowing data entry.
      localStorage.setItem(KEY + ':probe', '1');
      localStorage.removeItem(KEY + ':probe');
      return response({state, revision: saved.revision});
    }
    const body = JSON.parse(String(init.body));
    if (body.revision !== saved.revision) return response({error:'La agenda ha cambiado en otra ventana. Cierra el formulario y actualiza antes de guardar.'}, 409);
    const next = validateAgenda(body.state);
    const revision = saved.revision + 1;
    localStorage.setItem(KEY, JSON.stringify({state:next, revision}));
    return response({revision, updatedAt:new Date().toISOString()});
  } catch (e) {
    const message = e instanceof Error ? e.message : '';
    return response({error: /coincide|cliente|teléfono|repetidos/.test(message) ? message : 'Este navegador no permite guardar la copia local, o la copia no es válida. Abre el archivo en Chrome o utiliza la versión web.'}, 503);
  }
}
