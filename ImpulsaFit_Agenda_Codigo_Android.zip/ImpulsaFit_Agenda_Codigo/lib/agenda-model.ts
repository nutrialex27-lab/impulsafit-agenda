import { z } from 'zod';
export const ZONE = 'Europe/Madrid';
export const CENTER = 'Condes Wellness & Fitness';
export const LEGACY_POLICY = 'Para cambiar o cancelar, responde a este WhatsApp con al menos {horas} horas de antelación. Las cancelaciones fuera de plazo y las ausencias podrán contar como sesión consumida según las condiciones de tu bono previamente aceptadas. Si surge un imprevisto, contacta conmigo para revisar tu caso.';
export const CENTER_POLICY = 'Debes confirmar tu asistencia o cancelar con al menos {horas} horas de antelación. Si no recibimos respuesta, la reserva se dará por confirmada y la sesión se descontará de tu bono si no acudes. Las cancelaciones fuera de plazo también consumen una sesión del bono. No responder no cancela la reserva.';
export const services = { ems: 'EMS', personal: 'Entrenamiento personal', demo: 'Demo EMS' } as const;
export const statusLabels = { reserved: 'Reservada', confirmed: 'Confirmada', completed: 'Realizada', cancelled: 'Cancelada', late_cancel: 'Cancelación fuera de plazo', no_show: 'No presentado' } as const;
const id = z.string().min(1).max(100);
const stamp = z.string().datetime();
const message = z.object({ openedAt: stamp.optional(), sentAt: stamp.optional() });
export const settingsSchema = z.object({
  business: z.string().trim().min(1).max(100), location: z.string().trim().max(250),
  cancelHours: z.number().int().min(0).max(168), reminderHours: z.number().int().min(1).max(168),
  policy: z.string().trim().min(1).max(2000),
  replyPhone: z.string().regex(/^(?:[1-9][0-9]{6,14})?$/).default(''),
  directResponses: z.boolean().default(true), openWhatsAppOnSave: z.boolean().default(true),
});
export const clientSchema = z.object({
  id, name: z.string().trim().min(1).max(120), phone: z.string().regex(/^(?:[1-9][0-9]{6,14})?$/),
  optIn: z.boolean(), note: z.string().max(1000), createdAt: stamp,
});
export const appointmentSchema = z.object({
  id, clientId: id, start: stamp, duration: z.number().int().min(10).max(240),
  service: z.enum(['ems', 'personal', 'demo']), status: z.enum(['reserved','confirmed','completed','cancelled','late_cancel','no_show']),
  note: z.string().max(1000), createdAt: stamp, cancelledAt: stamp.optional(),
  terms: settingsSchema, confirmation: message, reminder: message,
  clientResponse: z.object({ choice: z.enum(['confirmed','cancelled']), receivedAt: stamp, source:z.enum(['manual','online']).default('manual') }).optional(),
  online:z.object({token:z.string().regex(/^[a-f0-9]{64}$/),editKey:z.string().regex(/^[a-f0-9]{64}$/),version:z.string().min(8).max(100),published:z.boolean(),dirty:z.boolean(),closed:z.boolean(),remoteRevision:z.number().int().nonnegative()}).optional(),
});
export const stateSchema = z.object({
  format: z.literal('impulsafit-agenda-v1'), settings: settingsSchema,
  clients: z.array(clientSchema).max(3000), appointments: z.array(appointmentSchema).max(15000),
  onlineRevocations:z.array(z.object({token:z.string().regex(/^[a-f0-9]{64}$/),editKey:z.string().regex(/^[a-f0-9]{64}$/),version:z.string().min(8).max(100)})).max(15000).default([]),
});
export type Client = z.infer<typeof clientSchema>;
export type Appointment = z.infer<typeof appointmentSchema>;
export type Settings = z.infer<typeof settingsSchema>;
export type AgendaState = z.infer<typeof stateSchema>;
export type MessageKind = 'confirmation' | 'reminder';
export const defaults: Settings = {
  business: 'ImpulsaFit', location: 'Condes Wellness & Fitness · Huelva', cancelHours: 24, reminderHours: 48,
  policy: CENTER_POLICY, replyPhone: '',directResponses:true,openWhatsAppOnSave:true,
};
export function emptyState(): AgendaState { return { format:'impulsafit-agenda-v1', settings:{...defaults}, clients:[], appointments:[],onlineRevocations:[] }; }
export const isActive = (a: Appointment) => a.status === 'reserved' || a.status === 'confirmed';
export function dayKey(value: string | number | Date = new Date()): string {
  const parts = new Intl.DateTimeFormat('en-CA',{timeZone:ZONE,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date(value));
  return ['year','month','day'].map(t=>parts.find(p=>p.type===t)!.value).join('-');
}
export function timeLabel(value:string|number|Date) { return new Intl.DateTimeFormat('es-ES',{timeZone:ZONE,hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(new Date(value)); }
export function dateLabel(value:string|number|Date, long=false) { return new Intl.DateTimeFormat('es-ES',{timeZone:ZONE,weekday:long?'long':undefined,day:'numeric',month:long?'long':'short',year:long?'numeric':undefined}).format(new Date(value)); }
export function addDays(day:string, amount:number) { const d=new Date(day+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+amount);return d.toISOString().slice(0,10); }
export function weekStart(day:string) { const d=new Date(day+'T12:00:00Z');return addDays(day,-((d.getUTCDay()+6)%7)); }
// Convert studio wall time independently of the device time zone.
export function madridISO(day:string, time:string): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(day)||!/^\d{2}:\d{2}$/.test(time)) throw new Error('Revisa la fecha y la hora.');
  const target=Date.parse(day+'T'+time+':00Z');
  if(!Number.isFinite(target)) throw new Error('Fecha no válida.');
  let guess=target;
  for(let i=0;i<4;i++) {
    const delta=target-Date.parse(dayKey(guess)+'T'+timeLabel(guess)+':00Z');
    if(delta===0) break;
    guess+=delta;
  }
  if(dayKey(guess)!==day || timeLabel(guess)!==time) throw new Error('Esa hora no existe por el cambio de horario. Elige otra.');
  return new Date(guess).toISOString();
}
export function normalizePhone(raw:string):string {
  let value=raw.trim().replace(/[\s().-]/g,'');
  if(!value)return '';
  if(value.startsWith('00')) value=value.slice(2);
  if(value.startsWith('+')) value=value.slice(1);
  else if(/^\d{9}$/.test(value)) value='34'+value;
  if(!/^[1-9][0-9]{6,14}$/.test(value))throw new Error('Usa un teléfono válido, con prefijo internacional (+34 para España).');
  return value;
}
export function validateAgenda(input:unknown):AgendaState {
  const s=stateSchema.parse(input);
  // Upgrade only the original, unedited template. Keep historical bookings and
  // custom agreements intact; unsent messages render the new centre wording.
  if(s.settings.policy===LEGACY_POLICY)s.settings.policy=CENTER_POLICY;
  if(new Set(s.clients.map(c=>c.id)).size!==s.clients.length || new Set(s.appointments.map(a=>a.id)).size!==s.appointments.length)throw new Error('La copia contiene identificadores repetidos.');
  const ids=new Set(s.clients.map(c=>c.id));
  const linked=s.appointments.filter(a=>a.online);
  if(new Set(linked.map(a=>a.online!.token)).size!==linked.length)throw new Error('Hay reservas que comparten el mismo enlace. Revisa la copia.');
  if(linked.some(a=>a.online!.token===a.online!.editKey))throw new Error('El enlace de respuesta no puede ser el acceso de edición.');
  if(s.appointments.some(a=>!ids.has(a.clientId))) throw new Error('Hay reservas sin un cliente válido.');
  if(s.clients.some(c=>c.optIn&&!c.phone)) throw new Error('Añade un teléfono antes de activar los avisos por WhatsApp.');
  const active=s.appointments.filter(isActive).sort((a,b)=>a.start.localeCompare(b.start));
  for(let i=1;i<active.length;i++) {
    const prev=active[i-1],current=active[i];
    if(Date.parse(current.start)<Date.parse(prev.start)+prev.duration*60000) {
      const name=s.clients.find(c=>c.id===prev.clientId)?.name;
      throw new Error(`Ese horario coincide con la reserva de ${name} del ${dateLabel(prev.start)} a las ${timeLabel(prev.start)}.`);
    }
  }
  return s;
}
export function deadline(a:Appointment) { return new Date(Date.parse(a.start)-a.terms.cancelHours*3600000).toISOString(); }
export function policyText(a:Appointment) { return (a.terms.policy===LEGACY_POLICY?CENTER_POLICY:a.terms.policy).replaceAll('{horas}',String(a.terms.cancelHours)); }
export function reservationLabel(a:Appointment,now=Date.now()) {
  return a.status==='reserved'&&!a.clientResponse&&now>=Date.parse(deadline(a))?'Confirmada · sin respuesta':statusLabels[a.status];
}
export const countsAsSession = (a:Appointment) => ['completed','late_cancel','no_show'].includes(a.status);
export function recordClientResponse(a:Appointment,choice:'confirmed'|'cancelled',receivedAt:string,source:'manual'|'online'='manual'):Appointment {
  const stamp=Date.parse(receivedAt);
  if(!Number.isFinite(stamp)||(source==='manual'&&stamp>Date.now()+60000))throw new Error('Revisa la fecha de recepción de la respuesta.');
  return {...a,clientResponse:{choice,receivedAt:new Date(stamp).toISOString(),source},status:choice==='confirmed'?'confirmed':stamp>Date.parse(deadline(a))?'late_cancel':'cancelled',cancelledAt:choice==='cancelled'?new Date(stamp).toISOString():undefined};
}
export function responseLinks(a:Appointment,phone:string) {
  const normalized=normalizePhone(phone);
  if(!normalized)return null;
  const details=`${dateLabel(a.start)} a las ${timeLabel(a.start)} · ${services[a.service]} · Ref. ${a.id}`;
  return {confirm:whatsappURL(normalized,`CONFIRMO mi sesión del ${details}.`),cancel:whatsappURL(normalized,`CANCELO mi sesión del ${details}.`)};
}
export function messageText(a:Appointment,c:Client,kind:MessageKind,replyPhone='',responseURL=''):string {
  const lead=kind==='confirmation'?'Tu reserva está anotada':'Te recuerdo tu próxima sesión';
  const links=responseLinks(a,replyPhone);
  const actions=responseURL?`*CONFIRMAR O CANCELAR TU SESIÓN*\n${responseURL}\n\nAbre el enlace y pulsa Confirmar o Cancelar. Tu respuesta queda registrada directamente en nuestra agenda; no tienes que enviar otro WhatsApp.`:links?`*Elige una opción:*\n\n✅ *CONFIRMAR SESIÓN*\n${links.confirm}\n\n❌ *CANCELAR SESIÓN*\n${links.cancel}\n\nPulsa el enlace de la opción elegida y después Enviar en WhatsApp.`:'Responde a este WhatsApp con una de estas dos opciones:\n✅ CONFIRMAR\n❌ CANCELAR';
  return `*${CENTER}*\nGestión de reservas · ${a.terms.business}\n\nHola, ${c.name.split(' ')[0]} 👋\n${lead}.\n\n📅 ${dateLabel(a.start,true)}\n🕒 ${timeLabel(a.start)} · ${a.duration} min\n💪 ${services[a.service]}${a.terms.location?'\n📍 '+a.terms.location:''}\n\n${actions}\n\n*Normativa del centro ${CENTER}*\n${policyText(a)}\n\n*Límite para cancelar sin consumir sesión:* ${dateLabel(deadline(a),true)} a las ${timeLabel(deadline(a))}.\n\n¡Te esperamos en Condes!`;
}
export function whatsappURL(phone:string,text:string) { if(!/^[1-9][0-9]{6,14}$/.test(phone))throw new Error('Falta un teléfono válido.');return `https://wa.me/${phone}?text=${encodeURIComponent(text)}`; }
export function pendingReminders(s:AgendaState,now=Date.now()) { return s.appointments.filter(a=>isActive(a)&&Date.parse(a.start)>now&&!a.reminder.sentAt&&Date.parse(a.start)-a.terms.reminderHours*3600000<=now).sort((a,b)=>a.start.localeCompare(b.start)); }
export function ics(s:AgendaState,list=s.appointments.filter(isActive)) {
  const esc=(t:string)=>t.replaceAll('\\','\\\\').replaceAll('\n','\\n').replaceAll(';','\\;').replaceAll(',','\\,');
  const dt=(v:string)=>new Date(v).toISOString().replace(/[-:]/g,'').replace(/\.\d{3}Z$/,'Z');
  const lines=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//ImpulsaFit//Agenda//ES','CALSCALE:GREGORIAN'];
  for(const a of list){const c=s.clients.find(c=>c.id===a.clientId)!; const text=messageText(a,c,'reminder',s.settings.replyPhone);lines.push('BEGIN:VEVENT',`UID:${a.id}@impulsafit-agenda`,`DTSTAMP:${dt(a.createdAt)}`,`DTSTART:${dt(a.start)}`,`DTEND:${dt(new Date(Date.parse(a.start)+a.duration*60000).toISOString())}`,`SUMMARY:${esc(services[a.service]+' · '+c.name)}`,`LOCATION:${esc(a.terms.location)}`,`DESCRIPTION:${esc(text+(c.phone?'\n\nPreparar WhatsApp: '+whatsappURL(c.phone,text):''))}`,'BEGIN:VALARM',`TRIGGER:-PT${a.terms.reminderHours}H`,'ACTION:DISPLAY','DESCRIPTION:Preparar recordatorio de ImpulsaFit','END:VALARM','END:VEVENT');}
  lines.push('END:VCALENDAR');
  return lines.map(line=>{let out='',part='',size=0;for(const ch of line){const n=new TextEncoder().encode(ch).length;if(size+n>75){out+=part+'\r\n';part=' ';size=1;}part+=ch;size+=n;}return out+part;}).join('\r\n')+'\r\n';
}
