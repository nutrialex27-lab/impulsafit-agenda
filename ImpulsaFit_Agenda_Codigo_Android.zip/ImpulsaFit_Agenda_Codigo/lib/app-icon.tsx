declare const __IF_AGENDA_ICON_DATA__: string;
export function AppIcon({size=42, className=''}:{size?:number;className?:string}) {
  const src=typeof __IF_AGENDA_ICON_DATA__ !== 'undefined' ? __IF_AGENDA_ICON_DATA__ : '/icon-192-coral.png';
  return <img src={src} width={size} height={size} alt="" className={'agenda-icon '+className}/>;
}
