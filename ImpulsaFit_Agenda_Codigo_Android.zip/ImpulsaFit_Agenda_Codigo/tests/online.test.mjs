import {test} from 'node:test';
import assert from 'node:assert/strict';
import {emptyState,validateAgenda,messageText,countsAsSession} from '../lib/agenda-model.ts';
import {newOnline,mergeOnline,reconcileOnline,onlineLink} from '../lib/agenda-online.ts';
const client={id:'c1',name:'Cliente de prueba',phone:'34600000000',optIn:true,note:'No publicar',createdAt:'2026-11-24T09:00:00.000Z'};
function fixture(){const s=emptyState();s.clients=[client];s.appointments=[{id:'a1',clientId:'c1',start:'2026-11-28T09:00:00.000Z',duration:35,service:'ems',status:'reserved',note:'Privada',createdAt:'2026-11-24T09:00:00.000Z',terms:{...s.settings},confirmation:{},reminder:{},online:newOnline()}];return s;}
test('each reservation gets independent, unguessable client and edit capabilities',()=>{
 const a=newOnline(),b=newOnline();assert.match(a.token,/^[a-f0-9]{64}$/);assert.notEqual(a.token,a.editKey);assert.notEqual(a.token,b.token);
 const s=fixture();s.appointments[0].online.published=true;s.appointments[0].online.dirty=false;const link=onlineLink(s.appointments[0]);assert.ok(link.endsWith('#'+s.appointments[0].online.token));assert.ok(!link.includes(s.appointments[0].online.editKey));
});
test('the client confirms without a second WhatsApp and only the public capability is shared',()=>{
 const s=fixture(),a=s.appointments[0];a.online.published=true;a.online.dirty=false;
 const text=messageText(a,client,'confirmation','',onlineLink(a));assert.match(text,/directamente en nuestra agenda/);assert.ok(text.includes(a.online.token));assert.ok(!text.includes(a.online.editKey));assert.ok(!text.includes('No publicar')&&!text.includes('Privada'));assert.ok(!text.includes('https://wa.me/'));
});
test('online answers update attendance once and a later cancellation replaces a confirmation',()=>{
 const a=fixture().appointments[0],r={version:a.online.version,choice:'confirmed',receivedAt:'2026-11-24T09:01:00.000Z',revision:1,closed:false};
 const confirmed=mergeOnline(a,r);assert.equal(confirmed.status,'confirmed');assert.equal(confirmed.clientResponse.source,'online');assert.deepEqual(mergeOnline(confirmed,r),confirmed);
 const cancelled=mergeOnline(confirmed,{...r,choice:'cancelled',receivedAt:'2026-11-27T09:01:00.000Z',revision:2});assert.equal(cancelled.status,'late_cancel');assert.equal(countsAsSession(cancelled),true);
});
test('old remote versions and responses to manually closed appointments cannot override local decisions',()=>{
 const a=fixture().appointments[0],r={version:'stale-version',choice:'confirmed',receivedAt:'2026-11-24T09:01:00.000Z',revision:10,closed:false};
 assert.deepEqual(mergeOnline(a,r),a);
 const done={...a,status:'completed'};assert.equal(mergeOnline(done,{...r,version:a.online.version}).status,'completed');
});
test('editing a published booking rotates the version; deleting it queues a revocation',()=>{
 const before=fixture();before.appointments[0].online.published=true;before.appointments[0].online.dirty=false;
 const edited=structuredClone(before);edited.appointments[0].start='2026-11-29T09:00:00.000Z';const revised=reconcileOnline(edited,before);
 assert.notEqual(revised.appointments[0].online.version,before.appointments[0].online.version);assert.equal(revised.appointments[0].online.token,before.appointments[0].online.token);assert.equal(revised.appointments[0].online.dirty,true);assert.equal(onlineLink(revised.appointments[0]),'');
 const removed=reconcileOnline({...before,appointments:[]},before);assert.equal(removed.onlineRevocations.length,1);assert.equal(removed.onlineRevocations[0].editKey,before.appointments[0].online.editKey);
 const roundtrip=validateAgenda(JSON.parse(JSON.stringify(removed)));assert.deepEqual(roundtrip.onlineRevocations,removed.onlineRevocations);
});
test('duplicate public links and publicly exposed edit capabilities are rejected on restore',()=>{
 const s=fixture();s.appointments.push({...s.appointments[0],id:'a2',start:'2026-11-29T09:00:00.000Z'});assert.throws(()=>validateAgenda(s),/mismo enlace/);
 s.appointments.pop();s.appointments[0].online.editKey=s.appointments[0].online.token;assert.throws(()=>validateAgenda(s),/edición/);
});
