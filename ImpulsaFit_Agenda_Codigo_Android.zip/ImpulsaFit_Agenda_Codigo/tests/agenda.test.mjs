import { test } from 'node:test';
import assert from 'node:assert/strict';
import {emptyState,validateAgenda,madridISO,addDays,normalizePhone,whatsappURL,pendingReminders,deadline,ics,messageText} from '../lib/agenda-model.ts';
const client={id:'c1',name:'Cliente de prueba',phone:'34600000000',optIn:true,note:'',createdAt:'2026-11-24T09:00:00.000Z'};
const appt=(s,overrides={})=>({id:'a1',clientId:'c1',start:'2026-11-27T09:00:00.000Z',duration:35,service:'ems',status:'reserved',note:'',createdAt:'2026-11-24T09:00:00.000Z',terms:{...s.settings},confirmation:{},reminder:{},...overrides});
const populated=()=>{const s=emptyState();s.clients=[{...client}];s.appointments=[appt(s)];return s;};
test('Madrid times stay constant across weekly daylight-saving changes',()=>{
 assert.equal(madridISO('2027-03-21','10:00'),'2027-03-21T09:00:00.000Z');
 assert.equal(madridISO(addDays('2027-03-21',7),'10:00'),'2027-03-28T08:00:00.000Z');
 assert.equal(madridISO('2026-10-18','10:00'),'2026-10-18T08:00:00.000Z');
 assert.equal(madridISO('2026-10-25','10:00'),'2026-10-25T09:00:00.000Z');
 assert.throws(()=>madridISO('2027-03-28','02:30'),/cambio de horario/);
});
test('overlapping and recurring reservations are rejected without blocking adjacent sessions',()=>{
 const s=populated();s.appointments.push(appt(s,{id:'a2',start:'2026-11-27T09:20:00.000Z'}));
 assert.throws(()=>validateAgenda(s),/coincide/);
 s.appointments[1].start='2026-11-27T09:35:00.000Z';assert.equal(validateAgenda(s).appointments.length,2);
 s.appointments[1].start='2026-11-27T09:20:00.000Z';s.appointments[0].status='cancelled';assert.equal(validateAgenda(s).appointments.length,2);
});
test('reminders only include active future appointments within their individual lead time',()=>{
 const s=populated();assert.equal(pendingReminders(s,Date.parse('2026-11-25T08:59:00Z')).length,0);
 assert.equal(pendingReminders(s,Date.parse('2026-11-25T09:00:00Z')).length,1);
 s.appointments[0].reminder.openedAt='2026-11-25T09:01:00Z';assert.equal(pendingReminders(s,Date.parse('2026-11-25T09:02:00Z')).length,1);
 s.appointments[0].reminder.sentAt='2026-11-25T09:03:00Z';assert.equal(pendingReminders(s,Date.parse('2026-11-25T09:04:00Z')).length,0);
 delete s.appointments[0].reminder.sentAt;assert.equal(pendingReminders(s,Date.parse(s.appointments[0].start)).length,0);
 s.appointments[0].status='cancelled';assert.equal(pendingReminders(s,Date.parse('2026-11-25T09:02:00Z')).length,0);
});
test('existing bookings keep their terms when the default cancellation period changes',()=>{
 const s=populated();s.settings.cancelHours=48;s.settings.business='Otro';
 assert.equal(deadline(s.appointments[0]),'2026-11-26T09:00:00.000Z');
 const text=messageText(s.appointments[0],client,'reminder');assert.match(text,/24 horas/);assert.match(text,/ImpulsaFit/);assert.match(text,/10:00/);
});
test('international phone formatting and WhatsApp query encoding',()=>{
 assert.equal(normalizePhone('600 000 000'),'34600000000');assert.equal(normalizePhone('+351 912 345 678'),'351912345678');assert.equal(normalizePhone('0034 600-000-000'),'34600000000');
 assert.throws(()=>normalizePhone('hola'));const text='Hola & fecha\n¡Mañana!';assert.equal(new URL(whatsappURL(client.phone,text)).searchParams.get('text'),text);
});
test('backups reject missing references, duplicate IDs and consent without a number',()=>{
 let s=populated();s.clients=[];assert.throws(()=>validateAgenda(s),/cliente/);
 s=populated();s.clients.push({...client});assert.throws(()=>validateAgenda(s),/repetidos/);
 s=populated();s.clients[0].phone='';assert.throws(()=>validateAgenda(s),/teléfono/);
});
test('calendar export uses UTC, stable IDs, folded UTF-8 lines and the configured alarm',()=>{
 const s=populated();const text=ics(s);assert.match(text,/DTSTART:20261127T090000Z/);assert.match(text,/UID:a1@impulsafit-agenda/);assert.match(text,/TRIGGER:-PT48H/);
 for(const line of text.split('\r\n'))assert.ok(Buffer.byteLength(line)<=75);
 assert.match(text.replaceAll('\r\n ',''),/https:\/\/wa.me\/34600000000/);
 assert.equal((text.match(/BEGIN:VEVENT/g)||[]).length,1);
});
