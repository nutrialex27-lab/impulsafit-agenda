# ImpulsaFit Agenda

Agenda privada, instalable como PWA, para ImpulsaFit en Condes Wellness & Fitness (Huelva). No utiliza APIs de pago, automatizadores ni suscripciones externas.

## Funciones

- Agenda diaria, semanal y mensual; reservas de EMS, entrenamiento personal y demos.
- Clientes con teléfono internacional y permiso de contacto por WhatsApp.
- Reservas semanales de 2, 4, 8 o 12 sesiones y detección de solapamientos.
- Mensajes editables de reserva y recordatorio, con normativa y fecha límite para cancelar.
- WhatsApp mediante enlaces oficiales `wa.me`: el usuario pulsa Enviar y confirma manualmente en la agenda. No hay envíos automáticos ni confirmación de entrega.
- Plazos iniciales editables: recordatorio 48 horas antes y cancelación con 24 horas de antelación. Las reservas conservan una copia de sus condiciones originales.
- Datos guardados en D1 por cuenta autenticada. Control de versión para no sobrescribir cambios de otro dispositivo.
- Exportación/restauración JSON y exportación ICS con alarmas. ICS es una copia, no sincronización bidireccional; se debe verificar su importación y las notificaciones del calendario receptor.
- Manifest y service worker para instalar en navegadores compatibles. La agenda requiere conexión; no se guardan datos de clientes en cachés del service worker.
- El borrador de una reserva se conserva durante la sesión del navegador mientras se edita. Los registros se guardan al confirmar el formulario.

## Alcance

La agenda es del entrenador. No incluye autoservicio de reserva para clientes, cobros, gestión de bonos ni envíos programados de WhatsApp. Las cancelaciones se registran; el texto de normativa debe adaptarse a las condiciones previamente acordadas con los clientes.

## Verificación

`node --experimental-strip-types --test tests/agenda.test.mjs`

`node node_modules/typescript/bin/tsc --noEmit`

Pruebas: horario de Madrid y cambio estacional, solapamientos, plazos de recordatorio, condiciones históricas, teléfonos/enlaces, integridad de copias e ICS con líneas UTF-8 plegadas.

Los recursos de alojamiento se gestionan con la cuenta del propietario. La aplicación no contiene facturación ni integraciones con coste externo. No se promete disponibilidad perpetua o condiciones futuras de terceros.


## Edición descargable (coral)

`public/ImpulsaFit_Agenda.html` es la edición para abrir directamente en un navegador. Incluye el programa, los estilos y el icono en un solo archivo. No requiere servidor, cuenta ni instalación de dependencias para usarla. Los datos quedan en el almacenamiento del navegador de ese dispositivo. La edición web conserva el guardado por cuenta y la sincronización entre dispositivos.

Para trasladar datos, exporta una copia JSON desde Ajustes y restáurala en la otra edición. Las dos agendas no se sincronizan automáticamente. Para generar de nuevo el HTML después de editar el código: `npm ci` y `npm run build:portable`.

Los WhatsApp se preparan en la agenda; el usuario pulsa Enviar en WhatsApp. No hay envío automático.

El icono coral se entrega con nombres de archivo nuevos para que el navegador pueda detectar la actualización de identidad visual.
