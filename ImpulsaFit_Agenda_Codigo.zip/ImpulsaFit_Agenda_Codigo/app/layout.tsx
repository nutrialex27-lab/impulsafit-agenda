import type { Metadata, Viewport } from 'next';
import './globals.css';
import './design-coral.css';
export const metadata: Metadata = {
  title: 'ImpulsaFit · Agenda',
  description: 'Tu estudio, en orden. Agenda de clientes y mensajes de reserva de ImpulsaFit.',
  manifest: '/manifest.webmanifest',
  icons: { icon: '/icon-192-coral.png', apple: '/icon-192-coral.png' },
  appleWebApp: { capable: true, statusBarStyle: 'default', title: 'ImpulsaFit Agenda' },
};
export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#F16B40' };
export default function RootLayout({children}: {children: React.ReactNode}) {
  return <html lang="es"><body>{children}</body></html>;
}
